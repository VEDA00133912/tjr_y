#!/bin/bash

git config --global user.name yuuki
git config --global user.email '<>'
